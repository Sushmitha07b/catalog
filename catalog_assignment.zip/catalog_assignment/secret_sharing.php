<?php
// Function to decode a value based on the base
function decodeBaseValue($value, $base) {
    return base_convert($value, $base, 10);
}

// Function to perform Lagrange Interpolation and find the constant term (c)
function lagrangeInterpolation($points) {
    $n = count($points);
    $c = 0;

    // Loop through each point and calculate the Lagrange basis polynomial
    for ($i = 0; $i < $n; $i++) {
        $xi = $points[$i][0];  // x-coordinate
        $yi = $points[$i][1];  // y-coordinate
        $term = $yi;

        for ($j = 0; $j < $n; $j++) {
            if ($i != $j) {
                $xj = $points[$j][0];
                $term *= (0 - $xj) / ($xi - $xj);  // Lagrange basis
            }
        }

        $c += $term;  // Add each term to get the constant term
    }

    return $c;
}

// Function to parse the JSON and prepare the points
function parseAndPreparePoints($json) {
    $data = json_decode($json, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        die('Error parsing JSON: ' . json_last_error_msg());
    }

    $keys = $data['keys'];
    $n = $keys['n'];
    $k = $keys['k'];

    $points = [];

    // Extract the points (x, y) from the JSON
    foreach ($data as $key => $value) {
        if (is_array($value) && isset($value['base']) && isset($value['value'])) {
            $x = intval($key);  // x-coordinate
            $base = intval($value['base']);
            $y = decodeBaseValue($value['value'], $base);  // Decode y-coordinate

            $points[] = [$x, intval($y)];
        }
    }

    return $points;
}

// Read JSON from the file (ensure these files exist in the same directory)
$json1 = file_get_contents('testcase1.json');  // First test case
$json2 = file_get_contents('testcase2.json');  // Second test case

// Check if files were read successfully
if ($json1 === false || $json2 === false) {
    die('Error reading JSON files.');
}

// Parse and decode the points
$points1 = parseAndPreparePoints($json1);
$points2 = parseAndPreparePoints($json2);

// Find the constant term (c) using Lagrange interpolation
$c1 = lagrangeInterpolation($points1);
$c2 = lagrangeInterpolation($points2);

// Output the results
echo "Secret for first test case (constant term c): " . $c1 . PHP_EOL;
echo "Secret for second test case (constant term c): " . $c2 . PHP_EOL;

// Optional: Check for wrong points in the second test case
// (Implement the logic to identify imposter points if required)
